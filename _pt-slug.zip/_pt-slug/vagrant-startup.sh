#!/bin/bash

echo " "
echo "    ,----.   @   @"
echo "   / ,---. .  \v/"
echo "   | | '\ \ \_/ ) - Plug the slug!"
echo " ,-\ '--' /.'  /"
echo "---'----'----'"
echo " "

service apache2 start
mailcatcher --http-ip=0.0.0.0 >/dev/null 2>&1

echo "ready"