#!/bin/bash

################ Import script args ################

SITE_NAME=$(echo "$1")
SITE_DIR=$SITE_NAME
TIMEZONE=$(echo "$2")
PACKAGES=$(echo $3 | tr ";" "\n")

APACHE_MODULES=$(echo $4 | tr ";" "\n")
APACHE_ENV=$(echo $5 | tr ";" "\n")

PHP_MODULES=$(echo $6 | tr ";" "\n")

################ Helpers ################


function slg() {
  echo " "
  echo "    ,----.   @   @"
  echo "   / ,---. .  \v/"
  echo "   | | '\ \ \_/ ) - $1 "
  echo " ,-\ '--' /.'  /"
  echo "---'----'----'"
  echo " "
}

function message() {
  echo ">>>>> ## $1 ##"
}

function info() {
  echo "$1"
}

################ Provision START ################

# fix "dpkg-preconfigure: unable to re-open stdin: No such file or directory"
export DEBIAN_FRONTEND=noninteractive

echo -e "\n"

slg "################ Provision START ################"

info "force_color_prompt..."
sed -i 's/#force_color_prompt=yes/force_color_prompt=yes/g' /root/.bashrc
sed -i 's/#force_color_prompt=yes/force_color_prompt=yes/g' /home/vagrant/.bashrc

info "Swap config..."
/bin/dd if=/dev/zero of=/var/swap.1 bs=1M count=1024 >/dev/null 2>&1
/sbin/mkswap /var/swap.1 >/dev/null 2>&1
/bin/chmod 0600 /var/swap.1 >/dev/null 2>&1
/sbin/swapon /var/swap.1 >/dev/null 2>&1

################ SSH ################
slg "Tune SSH"

info "Enable ssh password auth..."
sed -i 's/ChallengeResponseAuthentication no/ChallengeResponseAuthentication yes/g' /etc/ssh/sshd_config
service ssh restart

message "SSH login as 'vagrant@$SITE_NAME' with password 'vagrant' enabled"

################ Packages and repository update ################
slg "Update repos"

info "apt-get update..."
apt-get update >/dev/null
apt-get upgrade >/dev/null

info "Handle PPA..."
apt-get install -y software-properties-common >/dev/null 2>&1
apt-get install -y python-software-properties >/dev/null 2>&1
add-apt-repository -y ppa:ondrej/php >/dev/null 2>&1
add-apt-repository -y ppa:ondrej/apache2 >/dev/null 2>&1

info "Updating server with PPA..."
apt-get update >/dev/null
apt-get upgrade >/dev/null

################ Packages ################
slg "Packages"

info "Installing packages..."
for pkg in $PACKAGES
do
    info "-"$pkg
    apt-get install -y $pkg >/dev/null
done

############### Apache2 ################
slg "Apache2"

info "Installing Apache2..."
apt-get install -y apache2 >/dev/null

info "Adding vagrant user to www-data group..."
usermod -a -G vagrant www-data >/dev/null

info "Enabling Apache2 modules..."
for apch_module in $APACHE_MODULES
do
    info "-"$apch_module
    a2enmod $apch_module >/dev/null
done

info "Creating VirtualHost for $SITE_NAME..."
SetEnv=""
for apch_env in $APACHE_ENV
do
    env="  SetEnv "$(echo $apch_env | tr "=" " ")
    SetEnv+=$(printf '%s' "$env")$'\n'
done
VHOST=$(
  cat <<EOF
<VirtualHost *:80>
  ServerName $SITE_NAME
  DocumentRoot /var/www/$SITE_DIR/web
  DirectoryIndex index.php
  ErrorLog /var/log/apache2/$SITE_NAME.error.log
  CustomLog /var/log/apache2/$SITE_NAME.access.log combined
  <Directory "/var/www/$SITE_DIR/web">
    AllowOverride All
    Require all granted
  </Directory>
$SetEnv
</VirtualHost>
EOF
)
echo "${VHOST}" >/etc/apache2/sites-available/$SITE_NAME.conf
a2ensite $SITE_NAME.conf >/dev/null
a2dissite 000-default.conf >/dev/null

info "Restarting Apache2..."
service apache2 restart >/dev/null

################ PHP 8.1 ################
slg "PHP 8.1"

info "Installing core PHP 8.1..."
apt-get install -y php8.1 >/dev/null

info "Installing php8.1 modules..."
for php_module in $PHP_MODULES
do
    info "-"$php_module
    apt-get install -y php8.1-$php_module >/dev/null

    ## xdebug config
    if [ "$php_module" = "xdebug" ]; then
       xdebug_ini=$(
         cat <<EOF
xdebug.mode=debug
xdebug.start_with_request=yes
xdebug.discover_client_host=1
xdebug.client_host=192.168.56.1
xdebug.remote_handler=dbgp
xdebug.client_port = 9003

EOF
       )
       echo "${xdebug_ini}" >/etc/php/8.1/mods-available/zzz-xdebug.ini

       ln -s /etc/php/8.1/mods-available/zzz-xdebug.ini /etc/php/8.1/apache2/conf.d/zzz-xdebug.ini
       ln -s /etc/php/8.1/mods-available/zzz-xdebug.ini /etc/php/8.1/cli/conf.d/zzz-xdebug.ini
    fi
done

info "Tuning php.ini..."
cp /etc/php/8.1/apache2/php.ini /etc/php/8.1/apache2/php.ini.bak
sed -i 's#;date.timezone\([[:space:]]*\)=\([[:space:]]*\)*#date.timezone\1=\2\"'"$timezone"'\"#g' /etc/php/8.1/apache2/php.ini
sed -i 's#display_errors = Off#display_errors = On#g' /etc/php/8.1/apache2/php.ini
sed -i 's#display_startup_errors = Off#display_startup_errors = On#g' /etc/php/8.1/apache2/php.ini
sed -i 's#error_reporting = E_ALL & ~E_DEPRECATED & ~E_STRICT#error_reporting = E_ALL#g' /etc/php/8.1/apache2/php.ini
sed -i 's#;date.timezone\([[:space:]]*\)=\([[:space:]]*\)*#date.timezone\1=\2\"'"$timezone"'\"#g' /etc/php/8.1/cli/php.ini
sed -i 's#display_errors = Off#display_errors = On#g' /etc/php/8.1/cli/php.ini
sed -i 's#display_startup_errors = Off#display_startup_errors = On#g' /etc/php/8.1/cli/php.ini
sed -i 's#error_reporting = E_ALL & ~E_DEPRECATED & ~E_STRICT#error_reporting = E_ALL#g' /etc/php/8.1/cli/php.ini

info "Installing apache mod_php8.1..."
apt-get install -y libapache2-mod-php8.1 >/dev/null

info "Installing PEAR..."
apt-get install -y php-pear >/dev/null

info "Restarting Apache2..."
service apache2 restart >/dev/null

################ Composer ################
slg "Composer"

info "Installing latest v2 composer..."
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');" >/dev/null
php composer-setup.php >/dev/null
php -r "unlink('composer-setup.php');"
mv composer.phar /usr/local/bin/composer
chmod a+x /usr/local/bin/composer
composer self-update --2 >/dev/null 2>&1

################ SQLite3 ################
slg "SQLite3"

info "Installing SQLite3..."
apt-get install -y sqlite3 >/dev/null

################ Elasticsearch ################
#slg "Elasticsearch"
#
#info "Installing Elasticsearch(not available from rus ip, so needs VPN for)..."
##apt-get install -y openjdk-11-jdk >/dev/null
#wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo gpg --dearmor -o /usr/share/keyrings/elasticsearch-keyring.gpg >/dev/null 2>&1
#apt-get install -y apt-transport-https >/dev/null
#echo "deb [signed-by=/usr/share/keyrings/elasticsearch-keyring.gpg] https://artifacts.elastic.co/packages/8.x/apt stable main" | sudo tee /etc/apt/sources.list.d/elastic-8.x.list
#apt-get update >/dev/null
#apt-get install -y elasticsearch >/dev/null
#
#info "Tune Elasticsearch java vm options"
#sed -i 's#-Xms2g#-Xms512m#g' /etc/elasticsearch/jvm.options
#sed -i 's#-Xmx2g#-Xmx512m#g' /etc/elasticsearch/jvm.options
#
#service elasticsearch start

################ Ruby ################
slg "Ruby"

info "Installing..."
apt-get install -y ruby-full >/dev/null

info "Installing compile libs..."
apt-get install -y build-essential >/dev/null
apt-get install -y libffi-dev >/dev/null


################ Compass ################
slg "Compass"

info "Installing..."
gem install compass --no-document >/dev/null
message "'compass compile' available now"

################ MailCatcher ################
slg "MailCatcher"

info "Installing MailCatcher..."
info "libsqlite3-dev"
apt-get install -y libsqlite3-dev >/dev/null
gem install sqlite3 --version '1.4.2' --no-document >/dev/null

info "mailcatcher"
gem install mailcatcher --no-document >/dev/null

info "tune php ini for MailCatcher sendmail_path"
sed -i 's#^;\?sendmail_path[[:space:]]*=[[:print:]]*$#sendmail_path = /usr/bin/env catchmail -f dev@$SITE_NAME#g' /etc/php/8.1/apache2/php.ini
sed -i 's#^;\?sendmail_path[[:space:]]*=[[:print:]]*$#sendmail_path = /usr/bin/env catchmail -f dev@$SITE_NAME#g' /etc/php/8.1/cli/php.ini

mailcatcher --http-ip=0.0.0.0 >/dev/null 2>&1
message "MailCatcher web available on http:\\\\$SITE_NAME:1080"


################ Provision DONE ################
echo -e "\n"
echo "################ Provision DONE ################"
echo -e "\n"
